﻿using System;

namespace Laboratorio21
{
    public class Program
    {
        public static void Main()
        {
            //.
            MyClass.valor = 1;
            Console.WriteLine(MyClass.valor);
        }
    }

    public class MyClass
    {
        public static int valor;
    }
}
